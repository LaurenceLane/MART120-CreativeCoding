onEvent("Start", "click", function(){
setScreen("Interaction1");
});
onEvent("Interaction1", "click", function(){
setScreen("Interaction1.5");
});
var RosRel;
RosRel = 0;
onEvent("WhoAreYou", "click", function(){
RosRel = RosRel - 1;
setScreen("Interaction1.8");
});
onEvent("Okay", "click", function(){
RosRel = RosRel + 1;
setScreen("Interaction1.9");
});
onEvent("Interaction1.8", "click", function(){
setScreen("Interaction2");
});
onEvent("Interaction1.9", "click", function(){
setScreen("Interaction2");
});
onEvent("Interaction2", "click", function(){
setScreen("Interaction2.1");
});
onEvent("button7", "click", function(){
RosRel = RosRel + 1;
setScreen("Interaction3");
});
onEvent("button6", "click", function(){
RosRel = RosRel - 1;
setScreen("Interaction3");
});
onEvent("No", "click", function(){
setScreen("Interaction3.3");
});
onEvent("Interaction3.3", "click", function(){
setScreen("startScreen");
});
onEvent("Yes", "click", function(){
if (RosRel > 1) {
  setScreen("Interaction3.2");
} else {
  setScreen("Interaction3.1");
}
});
onEvent("Interaction3.1", "click", function(){
setScreen("startScreen");
});
onEvent("Interaction3.2", "click", function(){
setScreen("startScreen");
});
