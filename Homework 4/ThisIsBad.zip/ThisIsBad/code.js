var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["f399906b-826c-448d-8c65-298779774dc6","99a86358-f9a6-44a0-9f9b-6bac6bea71d3","a131d877-f24f-4f8e-98f2-ba3c6eaaa9ab"],"propsByKey":{"f399906b-826c-448d-8c65-298779774dc6":{"sourceSize":{"x":200,"y":70},"frameSize":{"x":200,"y":70},"frameCount":1,"frameDelay":12,"name":"WhereAmI.png_1","sourceUrl":null,"size":1330,"version":"p7JkA3d2MB4z.VMr0HFcKvZ4KVvHo2oR","looping":true,"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/f399906b-826c-448d-8c65-298779774dc6.png"},"99a86358-f9a6-44a0-9f9b-6bac6bea71d3":{"sourceSize":{"x":250,"y":88},"frameSize":{"x":250,"y":88},"frameCount":1,"frameDelay":12,"name":"IShouldnt.png_2","sourceUrl":null,"size":1330,"version":"xixthqP_Zp6CzsPR.VoQZbHnigC7AxmW","looping":true,"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/99a86358-f9a6-44a0-9f9b-6bac6bea71d3.png"},"a131d877-f24f-4f8e-98f2-ba3c6eaaa9ab":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"a7FFiq_Ddib51rf2lWymW8QGypSteMCp","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/a131d877-f24f-4f8e-98f2-ba3c6eaaa9ab.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

function draw() {
  background(rgb(0, 0, 0, 0.0));
  textSize(30);
  var Time = 0 + World.seconds;
  if (Time >= 0) {
    text(Time, 0, 15);
    var L1 = createSprite(190, 200);
    L1.setAnimation("WhereAmI.png_1");
    drawSprites();
  }
  if (Time >= 05) {
    text(Time, 0, 15);
    var L2 = createSprite(190, 200);
    L2.setAnimation("IShouldnt.png_2");
    drawSprites();
  }
}
background(rgb(0, 0, 0, 0.0));
//I started this trying to do a game, but ended up doing whatever this is after messing around and getting frustrated with the animation bit of the sprites for 4 hours. :') 

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
